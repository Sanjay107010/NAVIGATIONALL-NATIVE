import {StyleSheet, Text, View} from 'react-native';
import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import HomeScreen from '../screen/HomeScreen';
import NotificationsScreen from '../screen/NotificationsScreen';
import ProfileScreen from '../screen/ProfileScreen';
import SettingsScreen from '../screen/SettingsScreen';
import BottomNavigation from './BottomNavigation';

const Stack = createStackNavigator();

type Props = {};

const StackNavigation = (props: Props) => {
  return (
    <Stack.Navigator>
      <Stack.Screen name="BottomNavigation" component={BottomNavigation} />
      <Stack.Screen name="Notifications" component={NotificationsScreen} />
      <Stack.Screen name="Profile" component={ProfileScreen} />
      <Stack.Screen name="Settings" component={SettingsScreen} />
    </Stack.Navigator>
  );
};

export default StackNavigation;

const styles = StyleSheet.create({});

import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

type Props = {};

const NotificationsScreen = (props: Props) => {
  return (
    <View>
      <Text>NotificationsScreen</Text>
    </View>
  );
};

export default NotificationsScreen;

const styles = StyleSheet.create({});

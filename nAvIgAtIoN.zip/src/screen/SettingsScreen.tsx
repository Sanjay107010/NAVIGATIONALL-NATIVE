import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

type Props = {};

const SettingsScreen = (props: Props) => {
  return (
    <View>
      <Text>SettingsScreen</Text>
    </View>
  );
};

export default SettingsScreen;

const styles = StyleSheet.create({});

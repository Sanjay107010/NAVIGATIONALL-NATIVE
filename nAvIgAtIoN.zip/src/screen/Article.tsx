import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

type Props = {};

const Article = (props: Props) => {
  return (
    <View>
      <Text>Article</Text>
    </View>
  );
};

export default Article;

const styles = StyleSheet.create({});

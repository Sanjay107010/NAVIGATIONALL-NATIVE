import {StyleSheet, Text, View, TouchableOpacity} from 'react-native';
import React from 'react';
import ProfileScreen from './ProfileScreen';

type Props = {
  navigation: any;
};

const HomeScreen = (props: Props) => {
  return (
    <View>
      <TouchableOpacity onPress={() => props.navigation.navigate('Profile')}>
        <View>
          <Text style={styles.textstylhome}>profile Screen</Text>
        </View>
      </TouchableOpacity>
      <TouchableOpacity
        onPress={() => props.navigation.navigate('Notifications')}>
        <View>
          <Text style={styles.textstylhome}>Notifications Screen</Text>
        </View>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => props.navigation.navigate('Settings')}>
        <View>
          <Text style={styles.textstylhome}>Settings Screen</Text>
        </View>
      </TouchableOpacity>
    </View>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  textstylhome: {
    margin: 5,
    padding: 5,
  },
});

import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

type Props = {};

const ProfileScreen = (props: Props) => {
  return (
    <View>
      <Text>ProfileScreen</Text>
    </View>
  );
};

export default ProfileScreen;

const styles = StyleSheet.create({});
